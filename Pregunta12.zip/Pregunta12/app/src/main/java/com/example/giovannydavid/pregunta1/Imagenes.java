package com.example.giovannydavid.pregunta1;

/**
 * Created by giovannydavid on 11/07/2016.
 */
public class Imagenes {

    private String nombre;
    private int idDrawable;
//declara las imagenes y la posicion
    public Imagenes(String nombre, int idDrawable) {
        this.nombre = nombre;
        this.idDrawable = idDrawable;
    }
//Llama al nombre
    public String getNombre() {
        return nombre;
    }
//llama al IdDrawable para optener la posicion de la imagen
    public int getIdDrawable() {
        return idDrawable;
    }

    public int getId() {
        return nombre.hashCode();
    }
    //Declara las variables
    public static Imagenes[] ITEMS = {
            new Imagenes("Juego, 23 años", R.mipmap.ic_game),
            new Imagenes("Pelicula, 6 años", R.mipmap.ic_throne),
            new Imagenes("Game, 1 año", R.mipmap.ic_bote),
    };

    /**
     * Obtiene item basado en su identificador
     *
     * @param id identificador
     * @return Imagenes
     */

    //Llama a las imagenes
    public static Imagenes getItem(int id) {
        for (Imagenes item : ITEMS) {
            if (item.getId() == id) {
                return item;
            }
        }
        return null;
    }
}

