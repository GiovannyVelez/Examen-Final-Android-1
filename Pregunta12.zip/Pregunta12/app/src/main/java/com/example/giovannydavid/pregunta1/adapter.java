package com.example.giovannydavid.pregunta1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by giovannydavid on 11/07/2016.
 */
public class adapter extends BaseAdapter {
    private Context context;

    public adapter(Context context) {
        this.context = context;
    }

    //Contador
    @Override
    public int getCount() {
        return Imagenes.ITEMS.length;
    }
//Llama a la imagen y le pone una posicion
    @Override
    public Imagenes getItem(int position) {
        return Imagenes.ITEMS[position];
    }
//mira en numero en que se encuentra la imagen
    @Override
    public long getItemId(int position) {
        return getItem(position).getId();
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        if (view == null) {
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.grid_item, viewGroup, false);
        }

        ImageView imagenCoche = (ImageView) view.findViewById(R.id.imagen_coche);
        TextView nombreCoche = (TextView) view.findViewById(R.id.nombre_coche);

        final Imagenes item = getItem(position);
        imagenCoche.setImageResource(item.getIdDrawable());
        nombreCoche.setText(item.getNombre());
        return view;
    }

}